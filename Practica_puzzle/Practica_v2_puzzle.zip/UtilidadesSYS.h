/*
*	NOMBRES:
*		Alvaro Carpizo Garcia
*		Jhimmy Ender Candela
*/

//#pragma once
#ifndef UTILIDADESYS_H
#define UTILIDADESYS_H

using namespace std;

typedef unsigned char uint8;  // Byte
//typedef unsigned short int usint; // entero peque�o sin signo

void chcp1252();
void borrar();
void pausa();

void colorCTA(uint8 color, uint8 fondo);

#endif
